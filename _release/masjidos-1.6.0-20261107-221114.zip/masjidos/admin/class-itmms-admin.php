<?php
/**
 * Admin UI bootstrap: menu registration, fullscreen mode, asset loading.
 *
 * @package MasjidOS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin bootstrap class.
 */
final class ITMMS_Admin {

	/** @var ITMMS_Admin|null */
	private static ?ITMMS_Admin $instance = null;

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}
	private function __clone() {}

	/**
	 * Wire hooks into WordPress.
	 */
	public function init(): void {
		// Existing installs: show Welcome once until dismissed (does not overwrite 0).
		add_option( 'itmms_show_welcome', 1, '', false );

		add_action( 'admin_menu', [ $this, 'register_menu' ] );
		add_action( 'admin_menu', [ $this, 'reorder_submenu' ], 999 );
		add_action( 'wp_dashboard_setup', [ $this, 'register_wp_dashboard_widget' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'maybe_switch_ui_locale' ], 1 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_filter( 'admin_body_class', [ $this, 'add_fullscreen_class' ] );
		add_action( 'admin_bar_menu', [ $this, 'add_adminbar_exit_link' ], 999 );
	}

	/**
	 * Switch WordPress locale to the plugin UI language on MasjidOS pages
	 * so PHP strings and wp_set_script_translations use the same packs.
	 */
	public function maybe_switch_ui_locale(): void {
		if ( ! $this->is_itmms_page() ) {
			return;
		}

		$locale = ITMMS_Settings::ui_locale();
		if ( ! preg_match( '/^[A-Za-z0-9_@.-]+$/D', $locale ) ) {
			return;
		}

		if ( function_exists( 'switch_to_locale' ) ) {
			switch_to_locale( $locale );
		}

		unload_textdomain( 'masjidos' );
		if ( in_array( $locale, [ 'en_US', 'en' ], true ) ) {
			return;
		}

		$wporg_file   = WP_LANG_DIR . '/plugins/masjidos-' . $locale . '.mo';
		$bundled_file = ITMMS_PLUGIN_DIR . 'languages/masjidos-' . $locale . '.mo';
		if ( file_exists( $wporg_file ) ) {
			load_textdomain( 'masjidos', $wporg_file );
		} elseif ( file_exists( $bundled_file ) ) {
			load_textdomain( 'masjidos', $bundled_file );
		}
	}

	/**
	 * Register top-level admin menu.
	 */
	public function register_menu(): void {
		$capability = 'manage_options';
		$caps       = [
			'itmms_manage_prayers',
			'itmms_manage_events',
			'itmms_manage_announcements',
			'itmms_view_reports',
			'itmms_manage_settings',
		];

		foreach ( $caps as $cap ) {
			if ( current_user_can( $cap ) ) {
				$capability = $cap;
				break;
			}
		}

		add_menu_page(
			__( 'MasjidOS', 'masjidos' ),
			__( 'MasjidOS', 'masjidos' ),
			$capability,
			'masjidos',
			[ $this, 'render_app' ],
			'dashicons-building',
			80
		);

		add_submenu_page(
			'masjidos',
			__( 'Dashboard', 'masjidos' ),
			__( 'Dashboard', 'masjidos' ),
			$capability,
			'masjidos',
			[ $this, 'render_app' ]
		);

		if ( post_type_exists( ITMMS_Duas_Library::POST_TYPE ) ) {
			add_submenu_page(
				'masjidos',
				__( 'Duas Library', 'masjidos' ),
				__( 'Duas Library', 'masjidos' ),
				'edit_posts',
				'edit.php?post_type=' . ITMMS_Duas_Library::POST_TYPE
			);
		}

		if ( post_type_exists( ITMMS_Ask_Imam::POST_TYPE ) ) {
			add_submenu_page(
				'masjidos',
				__( 'Ask the Imam', 'masjidos' ),
				__( 'Ask the Imam', 'masjidos' ),
				'edit_posts',
				'edit.php?post_type=' . ITMMS_Ask_Imam::POST_TYPE
			);
		}
	}

	/**
	 * Keep Dashboard first, then All Articles, then the rest.
	 */
	public function reorder_submenu(): void {
		global $submenu;

		if ( empty( $submenu['masjidos'] ) || ! is_array( $submenu['masjidos'] ) ) {
			return;
		}

		$dashboard = null;
		$articles  = null;
		$rest      = [];

		foreach ( $submenu['masjidos'] as $item ) {
			$slug = isset( $item[2] ) ? (string) $item[2] : '';

			if ( 'masjidos' === $slug ) {
				$dashboard = $item;
				continue;
			}

			if ( false !== strpos( $slug, 'post_type=itmms_article' ) ) {
				$articles = $item;
				continue;
			}

			$rest[] = $item;
		}

		$ordered = [];
		if ( null !== $dashboard ) {
			$ordered[] = $dashboard;
		}
		if ( null !== $articles ) {
			$ordered[] = $articles;
		}

		$submenu['masjidos'] = array_merge( $ordered, $rest );
	}

	/**
	 * Output the SPA mount point.
	 */
	public function render_app(): void {
		echo '<div id="itmms-app"></div>';
	}

	/**
	 * Enqueue styles and scripts only on MasjidOS admin pages.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_assets( string $hook ): void {
		if ( ! $this->is_itmms_page( $hook ) ) {
			return;
		}

		wp_enqueue_media();

		wp_enqueue_style(
			'itmms-fonts',
			ITMMS_PLUGIN_URL . 'public/assets/css/tv-fonts.css',
			[],
			ITMMS_VERSION . '.' . (string) @filemtime( ITMMS_PLUGIN_DIR . 'public/assets/css/tv-fonts.css' )
		);

		wp_enqueue_style(
			'itmms-admin',
			ITMMS_PLUGIN_URL . 'admin/assets/css/admin.css',
			[ 'itmms-fonts' ],
			ITMMS_VERSION . '.' . (string) @filemtime( ITMMS_PLUGIN_DIR . 'admin/assets/css/admin.css' )
		);

		wp_enqueue_style(
			'itmms-public',
			ITMMS_PLUGIN_URL . 'public/assets/css/public.css',
			[ 'itmms-fonts' ],
			ITMMS_VERSION . '.' . (string) @filemtime( ITMMS_PLUGIN_DIR . 'public/assets/css/public.css' )
		);

		wp_register_script(
			'itmms-admin-shared',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/shared.js',
			[ 'wp-i18n' ],
			ITMMS_VERSION,
			true
		);

		wp_register_script(
			'itmms-admin-dashboard',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/dashboard.js',
			[ 'itmms-admin-shared' ],
			ITMMS_VERSION . '.' . (string) @filemtime( ITMMS_PLUGIN_DIR . 'admin/assets/js/modules/dashboard.js' ),
			true
		);

		wp_register_script(
			'itmms-admin-settings',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/settings.js',
			[ 'itmms-admin-shared' ],
			ITMMS_VERSION . '.' . (string) @filemtime( ITMMS_PLUGIN_DIR . 'admin/assets/js/modules/settings.js' ),
			true
		);

		wp_register_script(
			'itmms-admin-announcements',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/announcements.js',
			[ 'itmms-admin-shared' ],
			ITMMS_VERSION,
			true
		);

		wp_register_script(
			'itmms-admin-welcome',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/welcome.js',
			[ 'itmms-admin-shared', 'itmms-admin-dashboard' ],
			ITMMS_VERSION . '.' . (string) @filemtime( ITMMS_PLUGIN_DIR . 'admin/assets/js/modules/welcome.js' ),
			true
		);

		wp_register_script(
			'itmms-admin-docs',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/docs.js',
			[ 'itmms-admin-shared' ],
			ITMMS_VERSION,
			true
		);

		wp_register_script(
			'itmms-admin-events',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/events.js',
			[ 'itmms-admin-shared' ],
			ITMMS_VERSION,
			true
		);

		wp_register_script(
			'itmms-admin-minbar',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/minbar.js',
			[ 'itmms-admin-shared', 'wp-i18n' ],
			ITMMS_VERSION,
			true
		);

		wp_register_script(
			'itmms-admin-khutbah',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/khutbah.js',
			[ 'itmms-admin-minbar' ],
			ITMMS_VERSION,
			true
		);

		wp_register_script(
			'itmms-admin-features',
			ITMMS_PLUGIN_URL . 'admin/assets/js/modules/features.js',
			[ 'itmms-admin-shared' ],
			ITMMS_VERSION . '.' . (string) @filemtime( ITMMS_PLUGIN_DIR . 'admin/assets/js/modules/features.js' ),
			true
		);

		wp_enqueue_script(
			'itmms-public',
			ITMMS_PLUGIN_URL . 'public/assets/js/public.js',
			[],
			ITMMS_VERSION,
			true
		);

		$admin_deps = [
			'itmms-admin-shared',
			'itmms-admin-dashboard',
			'itmms-admin-welcome',
			'itmms-admin-settings',
			'itmms-admin-announcements',
			'itmms-admin-docs',
			'itmms-admin-events',
			'itmms-admin-minbar',
			'itmms-admin-khutbah',
			'itmms-admin-features',
		];

		/**
		 * Filter script handles that must load before the Free admin SPA (app.js).
		 * Pro may append its own registered module handles here.
		 *
		 * @param string[] $admin_deps Dependency handles.
		 */
		$admin_deps = (array) apply_filters( 'masjidos_admin_dependencies', $admin_deps );

		wp_enqueue_script(
			'itmms-admin',
			ITMMS_PLUGIN_URL . 'admin/assets/js/app.js',
			$admin_deps,
			ITMMS_VERSION . '.' . (string) @filemtime( ITMMS_PLUGIN_DIR . 'admin/assets/js/app.js' ),
			true
		);

		$this->inject_ui_script_translations( 'itmms-admin' );

		/**
		 * Filter Free admin sidebar nav extras.
		 * Each item: group_label, type (link|tab), label, icon, url|tab.
		 *
		 * @param array<int,array<string,mixed>> $nav Nav entries.
		 */
		$admin_nav = (array) apply_filters( 'masjidos_admin_nav', [] );

		wp_localize_script(
			'itmms-admin-shared',
			'itmmData',
			[
				'restUrl'      => rest_url( 'masjidos/v1/' ),
				'nonce'        => wp_create_nonce( 'wp_rest' ),
				'version'      => ITMMS_VERSION,
				'locale'       => ITMMS_Settings::ui_locale(),
				'uiLanguage'   => ITMMS_Settings::ui_language(),
				'uiLocale'     => ITMMS_Settings::ui_locale(),
				'uiIsRtl'      => ITMMS_Settings::ui_is_rtl(),
				'languagesUrl' => ITMMS_PLUGIN_URL . 'languages/',
				'i18nRev'      => (string) max(
					(int) @filemtime( ITMMS_PLUGIN_DIR . 'languages/masjidos-bn_BD-itmms-admin.json' ),
					(int) @filemtime( ITMMS_PLUGIN_DIR . 'languages/masjidos-ar-itmms-admin.json' )
				),
				'siteUrl'      => get_site_url(),
				'adminUrl'     => admin_url(),
				'siteTimezone' => wp_timezone_string(),
				'settings'     => ITMMS_Settings::get_all(),
				'modules'      => ITMMS_Settings::module_definitions(),
				'timetable'    => ITMMS_Prayer_Timetable::summary(),
				'onboarding'   => ITMMS_REST::get_onboarding_status(),
				'showWelcome'  => (int) get_option( 'itmms_show_welcome', 0 ) === 1,
				'user'         => [
					'id'   => get_current_user_id(),
					'name' => wp_get_current_user()->display_name,
				],
				'pro'          => masjidos_pro_localize(),
				'proUrl'       => masjidos_pro_url(),
				'adminNav'     => $admin_nav,
			]
		);
	}

	/**
	 * Force-load Jed locale data for the plugin UI language.
	 * Ensures translations work even when WordPress does not have that locale installed.
	 *
	 * @param string $handle Script handle (file suffix: masjidos-{locale}-{handle}.json).
	 */
	private function inject_ui_script_translations( string $handle ): void {
		$locale = ITMMS_Settings::ui_locale();
		if ( in_array( $locale, [ 'en_US', 'en' ], true ) ) {
			wp_add_inline_script(
				'wp-i18n',
				'if ( window.wp && window.wp.i18n && window.wp.i18n.setLocaleData ) { window.wp.i18n.setLocaleData( { "": { domain: "messages", lang: "en_US", "plural-forms": "nplurals=2; plural=(n != 1);" } }, "masjidos" ); }',
				'after'
			);
			return;
		}

		$path = ITMMS_PLUGIN_DIR . 'languages/masjidos-' . $locale . '-' . $handle . '.json';
		if ( ! is_readable( $path ) ) {
			return;
		}

		$decoded = json_decode( (string) file_get_contents( $path ), true );
		if ( empty( $decoded['locale_data']['messages'] ) || ! is_array( $decoded['locale_data']['messages'] ) ) {
			return;
		}

		wp_add_inline_script(
			'wp-i18n',
			sprintf(
				'wp.i18n.setLocaleData( %s, %s );',
				wp_json_encode( $decoded['locale_data']['messages'] ),
				wp_json_encode( 'masjidos' )
			),
			'after'
		);
	}

	/**
	 * Append fullscreen class to MasjidOS admin pages.
	 *
	 * @param string $classes Space-separated body class string.
	 * @return string
	 */
	public function add_fullscreen_class( string $classes ): string {
		if ( $this->is_itmms_page() ) {
			$classes .= ' itmms-fullscreen';
			$ui = ITMMS_Settings::ui_language();
			$classes .= ' itmms-ui-' . $ui;
			if ( 'ar' === $ui ) {
				$classes .= ' itmms-ui-rtl rtl';
			}
		}

		return $classes;
	}

	/**
	 * Add a WordPress escape link to the WP admin bar.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Admin bar instance.
	 */
	public function add_adminbar_exit_link( WP_Admin_Bar $wp_admin_bar ): void {
		if ( ! $this->is_itmms_page() ) {
			return;
		}

		$wp_admin_bar->add_node(
			[
				'id'    => 'itmms-exit',
				'title' => '&larr; ' . __( 'WordPress Dashboard', 'masjidos' ),
				'href'  => admin_url(),
				'meta'  => [ 'class' => 'itmms-exit-link' ],
			]
		);
	}

	/**
	 * Register native WordPress Admin Dashboard widget (wp-admin/index.php).
	 */
	public function register_wp_dashboard_widget(): void {
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'itmms_manage_prayers' ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'itmms_wp_dashboard_widget',
			__( 'MasjidOS — Prayer Times & Setup Checklist', 'masjidos' ),
			[ $this, 'render_wp_dashboard_widget' ]
		);
	}

	/**
	 * Render native WordPress Admin Dashboard widget.
	 */
	public function render_wp_dashboard_widget(): void {
		$settings     = ITMMS_Settings::get_all();
		$prayer_times = ITMMS_Prayer_Times::today();
		$next_prayer  = $prayer_times['next_prayer'] ?? [];
		$onboarding   = ITMMS_REST::get_onboarding_status( $settings );
		$hijri        = ITMMS_Hijri::for_date( new DateTimeImmutable( 'now', wp_timezone() ), (int) ( $settings['hijri_adjustment'] ?? 0 ), ITMMS_Settings::ui_language() );

		$step_labels = [
			'location'      => __( 'Location & timezone configured', 'masjidos' ),
			'iqamah_jumuah' => __( 'Iqamah & Jumuah times set', 'masjidos' ),
			'starter_page'  => __( 'Prayer times page published', 'masjidos' ),
			'first_content' => __( 'First notice or khutbah added', 'masjidos' ),
			'tv_preview'    => __( 'Mosque TV display previewed', 'masjidos' ),
		];
		?>
		<div class="itmms-wp-widget" style="font-size:13px;line-height:1.5;color:#1e293b;">
			<div style="display:flex;justify-content:space-between;align-items:center;background:linear-gradient(135deg,#064e3b,#047857);color:#fff;padding:12px 14px;border-radius:8px;margin-bottom:12px;">
				<div>
					<div style="font-size:11px;opacity:.85;text-transform:uppercase;letter-spacing:.04em;"><?php echo esc_html__( 'Next Prayer', 'masjidos' ); ?></div>
					<strong style="font-size:16px;"><?php echo esc_html( (string) ( $next_prayer['name'] ?? '—' ) ); ?> · <?php echo esc_html( (string) ( $next_prayer['time'] ?? '' ) ); ?></strong>
				</div>
				<div style="text-align:right;font-size:12px;opacity:.92;">
					<div><?php echo esc_html( (string) ( $hijri['label'] ?? '' ) ); ?></div>
					<small><?php echo esc_html( (string) ( $settings['city'] ?? '' ) ); ?></small>
				</div>
			</div>

			<div style="margin-bottom:12px;padding:10px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
				<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
					<strong><?php echo esc_html__( 'Masjid Setup Progress', 'masjidos' ); ?></strong>
					<span style="font-weight:700;color:#047857;">
						<?php
						printf(
							/* translators: 1: completed steps, 2: total steps, 3: percent */
							esc_html__( '%1$d/%2$d (%3$d%%)', 'masjidos' ),
							(int) $onboarding['completed'],
							(int) $onboarding['total'],
							(int) $onboarding['percent']
						);
						?>
					</span>
				</div>
				<div style="height:7px;background:#e2e8f0;border-radius:999px;overflow:hidden;margin-bottom:8px;">
					<div style="height:100%;width:<?php echo esc_attr( (string) (int) $onboarding['percent'] ); ?>%;background:#059669;border-radius:999px;"></div>
				</div>
				<ul style="margin:0;padding:0;list-style:none;display:grid;gap:4px;">
					<?php foreach ( (array) $onboarding['steps'] as $step ) : ?>
						<?php
						$key   = (string) ( $step['key'] ?? '' );
						$done  = ! empty( $step['done'] );
						$label = $step_labels[ $key ] ?? $key;
						?>
						<li style="display:flex;align-items:center;gap:6px;color:<?php echo $done ? '#065f46' : '#64748b'; ?>;">
							<span style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;font-size:10px;font-weight:700;background:<?php echo $done ? '#d1fae5' : '#e2e8f0'; ?>;color:<?php echo $done ? '#047857' : '#64748b'; ?>;">
								<?php echo $done ? '&#10003;' : '&bull;'; ?>
							</span>
							<span><?php echo esc_html( $label ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>

			<div style="display:flex;flex-wrap:wrap;gap:6px;">
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=masjidos' ) ); ?>"><?php echo esc_html__( 'Open MasjidOS', 'masjidos' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=masjidos&itmms_view=welcome' ) ); ?>"><?php echo esc_html__( 'Setup Wizard', 'masjidos' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=masjidos&itmms_view=announcements' ) ); ?>"><?php echo esc_html__( 'Add Notice', 'masjidos' ); ?></a>
				<a class="button" href="<?php echo esc_url( home_url( '/masjidos-display/' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'TV Display', 'masjidos' ); ?></a>
			</div>
		</div>
		<?php
	}

	/**
	 * Check whether the current request is a MasjidOS Free SPA admin page.
	 * Sibling Pro screens (page=masjidos-pro-*) stay on normal WP admin chrome.
	 *
	 * @param string $hook Optional hook suffix.
	 */
	private function is_itmms_page( string $hook = '' ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		if ( $page && 0 === strpos( $page, 'masjidos-pro' ) ) {
			return false;
		}
		if ( $hook && false !== strpos( $hook, 'masjidos-pro' ) ) {
			return false;
		}

		if ( $hook && false !== strpos( $hook, 'masjidos' ) ) {
			return true;
		}

		return '' !== $page && 0 === strpos( $page, 'masjidos' );
	}
}
